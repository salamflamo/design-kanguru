Font: Queen of Camelot (Regular and Italic)
Version: 3.0 (updated 2/19/2017)
Dennis Ludlow 2015 all rights reserved
Sharkshock Productions
dennis@sharkshock.net


Long Live the Queen! Greetings subjects. This is an update of an older display font project containing more visually appealing glyphs with proportionate weights and kerning added. There is a smooth feel with the rounded joins that has a consistent presence throughout it's entirety. This typeface
 has been a popular choice in publications, branding, and sports. Punctuation is included as is basic latin, some ligatures, and diacritics for Poland and Eastern Europe. Extended latin can be added upon purchase of a commercial license. Contact me for more info on this. There are uppercase
letters only.

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license.
If you've previously licensed the older version you're grandfathered into this version. Thank you! I also design custom fonts for businesses, logos, and many other things. If you'd like to 
leave me a donation you can use the same address via paypal. Your generosity will be most appreciated! Enjoy!


visit www.sharkshock.net for more and take a bite out of BORING design!

tags: weight, sans, san serif, jolly, logo, sports, newspaper, headlines, book, publishing, title, curve, royal, undulating, curvy, font, typeface, branding, design, graphic, German, Polish, Europe, European, French, Latin

